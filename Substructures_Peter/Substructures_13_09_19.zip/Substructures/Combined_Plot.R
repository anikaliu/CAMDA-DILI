#https://stackoverflow.com/questions/47542849/marginal-plots-using-axis-canvas-in-cowplot-how-to-insert-gap-between-main-pane
# http://www.lreding.com/nonstandard_deviations/2017/08/19/cowmarg/

library(tidyverse) # for ggplot2
library(magrittr) # for pipes and %<>%
library(ggpubr) # for theme_pubr()
library(cowplot)

df <- read_csv("./PPV_0_All_substructure_Stats.csv")


original_plot <- ggplot(data = df, mapping = aes(x = PPV, y = perc_hits, color=factor(Source))) +
  geom_point(alpha = 0.9) +
  xlab("Precision") +
  ylab("DILI compounds with substructure (%)")  +
  scale_color_manual(name="Substructure Source",
                     labels=c("Hewitt et al. (2013)", "Liu et al. (2015)", "SARpy", "MOSS"),
                     values=c("red","forestgreen","cyan2","purple")) +
  scale_fill_manual(values=c("red","forestgreen","cyan2","purple")) +
  theme(legend.position="bottom")
original_plot


y_box <- axis_canvas(original_plot, axis = "y") +
  geom_boxplot(data = df, aes(x=factor(Source),y = perc_hits, color = factor(Source))) + scale_fill_manual(values = c("red","green","blue","blue"))+ scale_x_discrete() 
 

x_box <- axis_canvas(original_plot,axis="x", coord_flip = TRUE) + 
  geom_boxplot(data=df, aes(y=PPV, x = factor(Source), color = factor(Source))) + scale_fill_manual(values = c("red","green","blue","blue")) + scale_x_discrete() +coord_flip() 


#l <- ggplot(data = df, aes(x=factor(Source),y = perc_hits, color = factor(Source))) +
#  geom_boxplot()
#ggdraw(l)

p1 <- insert_xaxis_grob(original_plot,x_box,grid::unit(0.6, "in"),position = "top")
p2 <- insert_yaxis_grob(p1, y_box, grid::unit(0.6, "in"),position = "right")

#p3 <- p2 + 
#    scale_fill_discrete(name = "Substructure Source", labels = c("MOSS", "SARpy", "Hewitt", "Liu"))
  


ggdraw(p2)

